# Testning Av Programvara
Kära elever!

Här kommer jag att lägga upp det material som vi har gått igenom under kursens gång. 
Se till att hålla er version av git repository uppdaterad för att få de senaste ändringarna som gjorts!
Ifall ni får eventuella problem eller behöver hjälp med git så kan ni gärna höra av er till mig via E-mail.

MVH
Simon Baghdo
